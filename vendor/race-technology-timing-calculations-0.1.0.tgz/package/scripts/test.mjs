import { spawnSync } from "node:child_process";
import { mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const output = resolve(root, ".generated/calculations.test.mjs");
mkdirSync(dirname(output), { recursive: true });
const esbuild = resolve(root, "../../node_modules/esbuild/bin/esbuild");
const built = spawnSync(esbuild, [resolve(root, "test/calculations.test.ts"), "--bundle", "--platform=node", "--format=esm", "--target=node20", `--outfile=${output}`], { stdio: "inherit" });
if (built.status !== 0) process.exit(built.status ?? 1);
const tested = spawnSync(process.execPath, [output], { stdio: "inherit" });
process.exit(tested.status ?? 1);
