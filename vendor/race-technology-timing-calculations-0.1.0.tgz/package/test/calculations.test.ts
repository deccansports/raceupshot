import assert from "node:assert/strict";
import { calculateDurations, normalizeStartConfiguration, normalizeTimestampUtc, resolveOfficialAthleteStart, selectTimingRead } from "../src/index.js";

assert.equal(normalizeTimestampUtc("2026-10-04 06:00:00", "Asia/Kolkata"), "2026-10-04T00:30:00.000Z");
const configuration = normalizeStartConfiguration({ mode: "CHIP", gunStartTime: "2026-10-04T00:00:00.000Z" });
assert.deepEqual(resolveOfficialAthleteStart({ configuration, acceptedChipStartTime: "2026-10-04T00:00:12.000Z" }), { timingMode: "CHIP", resolvedAthleteStartTime: "2026-10-04T00:00:12.000Z", startSource: "accepted_chip_start" });
const selected = selectTimingRead(null, { readId: "r1", timestamp: "2026-10-04T00:10:00.000Z", elapsedSeconds: 600, status: "valid" }, { key: "cp", readSelectionRule: "first" });
assert.equal(selected?.readId, "r1");
const metrics = calculateDurations({ start: { readId: "s", elapsedSeconds: 0, status: "valid" }, finish: { readId: "f", elapsedSeconds: 3600, status: "official" } }, { splits: [{ key: "start", readSelectionRule: "first" }, { key: "finish", readSelectionRule: "last", isRaceFinish: true }], legs: [{ type: "run", order: 0, startSplitKey: "start", finishSplitKey: "finish", distanceKm: 10 }], transitions: [], totalDistanceKm: 10 });
assert.equal(metrics.runSeconds, 3600);
assert.equal(metrics.overallSeconds, 3600);
console.log("timing-calculations unit tests passed");
