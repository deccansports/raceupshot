export type TimingMode = "CHIP" | "GUN" | "WAVE";
export type StartReadStatus = "VALID" | "INVALID" | "PRE_START" | "DUPLICATE" | "IGNORED" | "SECOND_PASSAGE" | "MANUAL";

export interface StartConfiguration {
  mode: TimingMode;
  gunStartTime: string | null;
  officialStartSource?: "FEIBOT_CONTEST" | "TICKET_CONFIGURATION" | "EVENT_CONFIGURATION" | null;
  ignoreReadsBeforeOfficialStart: true;
  dedupWindowSeconds: number;
  validWindowMinutes: number;
  dnsGraceMinutes: number;
  strictFinalCutoff: boolean;
  startWindowOpenTime: string | null;
  startWindowCloseTime: string | null;
  passageGapSeconds: number;
  timingReorderBufferMs: number;
  lockFirstAcceptedRead: true;
  storeAllRawReads: true;
  minimumFinishGapSeconds: number;
  requireMandatorySplitsBeforeFinish: boolean;
}

export interface TimingRead {
  readId: string;
  eventId?: string;
  contestUuid?: string;
  participantUuid?: string;
  providerParticipantUuid?: string;
  bib?: string | null;
  chipCode?: string | null;
  splitKey?: string;
  providerSplitId?: string;
  providerTimingPointId?: string;
  readerUuid?: string | null;
  timestamp?: string | null;
  occurredAt?: string | null;
  receivedAt?: string | null;
  timeOfDay?: string | null;
  elapsedSeconds?: number | null;
  overallElapsedSeconds?: number | null;
  segmentElapsedSeconds?: number | null;
  chipElapsedSeconds?: number | null;
  gunElapsedSeconds?: number | null;
  waveElapsedSeconds?: number | null;
  passNumber?: number | null;
  source?: string | null;
  status: string;
}

export interface StartTimingState {
  officialStartTime: string | null;
  chipStartDetectionTime: string | null;
  startTimeSource: TimingMode | null;
  startTimeLocked: boolean;
  acceptedReadId: string | null;
  startPassageId: string | null;
  startReadCount: number;
  startStatus: "NOT_STARTED" | "NO_START_DETECTION" | "ON_COURSE";
  updatedAt: string | null;
  startInferenceSource: "manual_override" | "official_gun_start" | "official_wave_start" | "accepted_chip_start" | "awaiting_chip_start" | null;
}

export interface TimingPassage {
  id: string;
  eventId?: string;
  contestUuid?: string;
  participantUuid?: string;
  bib: string | null;
  chipCode: string | null;
  timingPointUuid?: string;
  timingPointType: "START";
  readerUuid: string | null;
  passageFirstTimestamp: string;
  passageLastTimestamp: string;
  readCount: number;
  passageStatus: "VALID_START" | "PRE_START" | "MANUAL" | "INVALID" | "SECOND_PASSAGE";
  usedForTiming: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SplitRule {
  key: string;
  readSelectionRule: "first" | "last" | "auto" | "fastest" | "pass_number" | "manual";
  passNumber?: number | null;
  isFinish?: boolean;
  isRaceFinish?: boolean;
  cumulativeDistanceKm?: number | null;
}

export type LegType = "swim" | "bike" | "run" | "run_1" | "run_2" | string;
export interface CourseLeg { type: LegType; order: number; startSplitKey: string; finishSplitKey: string; distanceKm: number; }
export interface CourseTransition { key: string; type: string; order?: number; startSplitKey: string; finishSplitKey: string; }
export interface ContestCourse {
  splits: SplitRule[];
  legs: CourseLeg[];
  transitions: CourseTransition[];
  configuredRaceDistanceKm?: number | null;
  totalDistanceKm?: number | null;
}

export interface CalculatedDurations {
  swimSeconds: number | null;
  t1Seconds: number | null;
  bikeSeconds: number | null;
  t2Seconds: number | null;
  runSeconds: number | null;
  overallSeconds: number | null;
  averageSwimPaceSecondsPer100m: number | null;
  averageBikeSpeedKmh: number | null;
  averageRunPaceSecondsPerKm: number | null;
  averageRacePaceSecondsPerKm: number | null;
}
