import type { SplitRule, TimingRead } from "./types.js";

const ACCEPTED_STATUSES = new Set(["valid", "confirmed", "corrected", "official", "manual_corrected"]);
export function elapsedSeconds(read: TimingRead | null | undefined): number | null {
  const value = read?.overallElapsedSeconds ?? read?.elapsedSeconds;
  return typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : null;
}
export function acceptedElapsedSeconds(read: TimingRead | null | undefined): number | null {
  return read && ACCEPTED_STATUSES.has(read.status) ? elapsedSeconds(read) : null;
}
function readPriority(read: TimingRead): number {
  if (read.source === "final" || read.status === "official") return 4;
  if (read.source === "correction" || read.status === "manual_corrected") return 3;
  if (read.status === "valid" || read.status === "confirmed" || read.status === "corrected") return 2;
  if (read.status === "estimated") return 1;
  return 0;
}

export function selectTimingRead(existing: TimingRead | null, candidate: TimingRead, split: SplitRule): TimingRead | null {
  if (elapsedSeconds(candidate) === null || candidate.status === "invalid" || candidate.status === "rejected") return existing;
  if (!existing) {
    if (split.readSelectionRule === "pass_number" && split.passNumber !== candidate.passNumber) return null;
    if (split.readSelectionRule === "manual" && readPriority(candidate) < 3) return null;
    return candidate;
  }
  const existingPriority = readPriority(existing); const candidatePriority = readPriority(candidate);
  if (candidatePriority !== existingPriority) return candidatePriority > existingPriority ? candidate : existing;
  if (split.readSelectionRule === "first") {
    const candidateElapsed = elapsedSeconds(candidate) ?? Infinity; const existingElapsed = elapsedSeconds(existing) ?? Infinity;
    if (candidateElapsed !== existingElapsed) return candidateElapsed < existingElapsed ? candidate : existing;
    const candidateTime = Date.parse(candidate.timestamp ?? candidate.occurredAt ?? ""); const existingTime = Date.parse(existing.timestamp ?? existing.occurredAt ?? "");
    return Number.isFinite(candidateTime) && (!Number.isFinite(existingTime) || candidateTime < existingTime) ? candidate : existing;
  }
  if (split.readSelectionRule === "fastest") return (candidate.segmentElapsedSeconds ?? candidate.elapsedSeconds ?? Infinity) < (existing.segmentElapsedSeconds ?? existing.elapsedSeconds ?? Infinity) ? candidate : existing;
  if (split.readSelectionRule === "pass_number") return candidate.passNumber === split.passNumber ? candidate : existing;
  if (split.readSelectionRule === "manual") return candidatePriority >= 3 ? candidate : existing;
  const candidateTime = Date.parse(candidate.timestamp ?? candidate.occurredAt ?? ""); const existingTime = Date.parse(existing.timestamp ?? existing.occurredAt ?? "");
  return Number.isFinite(candidateTime) && (!Number.isFinite(existingTime) || candidateTime >= existingTime) ? candidate : existing;
}
