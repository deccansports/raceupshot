import { acceptedElapsedSeconds } from "./reads.js";
import type { CalculatedDurations, ContestCourse, TimingRead } from "./types.js";

function difference(finish: number | null, start: number | null): number | null { if (finish === null || start === null) return null; const value = finish - start; return Number.isFinite(value) && value >= 0 ? value : null; }
function divide(value: number | null, divisor: number): number | null { if (value === null || !Number.isFinite(divisor) || divisor <= 0) return null; const result = value / divisor; return Number.isFinite(result) && result >= 0 ? result : null; }

export function calculateDurations(reads: Record<string, TimingRead | null>, contest: ContestCourse): CalculatedDurations {
  const between = (start: string | null | undefined, finish: string | null | undefined) => start && finish ? difference(acceptedElapsedSeconds(reads[finish]), acceptedElapsedSeconds(reads[start])) : null;
  const legDurations = [...(contest.legs || [])].sort((a, b) => a.order - b.order).map((leg) => ({ leg, duration: between(leg.startSplitKey, leg.finishSplitKey) }));
  const durationForLeg = (types: string[]) => { const matches = legDurations.filter(({ leg }) => types.includes(leg.type)); return matches.length === 0 || matches.some(({ duration }) => duration === null) ? null : matches.reduce((total, { duration }) => total + (duration ?? 0), 0); };
  const transitionDuration = (key: "t1" | "t2") => { const transition = (contest.transitions || []).find((row) => row.key === key || row.type === key); return transition ? between(transition.startSplitKey, transition.finishSplitKey) : null; };
  const swimSeconds = durationForLeg(["swim"]) ?? difference(acceptedElapsedSeconds(reads.swim_finish), acceptedElapsedSeconds(reads.swim_start));
  const t1Seconds = transitionDuration("t1") ?? difference(acceptedElapsedSeconds(reads.bike_start), acceptedElapsedSeconds(reads.swim_finish));
  const bikeSeconds = durationForLeg(["bike"]) ?? difference(acceptedElapsedSeconds(reads.bike_finish), acceptedElapsedSeconds(reads.bike_start));
  const t2Seconds = transitionDuration("t2") ?? difference(acceptedElapsedSeconds(reads.run_start ?? reads.run_2_start), acceptedElapsedSeconds(reads.bike_finish));
  const runSeconds = durationForLeg(["run", "run_1", "run_2"]) ?? difference(acceptedElapsedSeconds(reads.run_finish ?? reads.run_2_finish), acceptedElapsedSeconds(reads.run_start ?? reads.run_1_start));
  const finish = contest.splits.find((split) => split.isRaceFinish) ?? contest.splits.find((split) => split.isFinish) ?? contest.splits.at(-1);
  const overallSeconds = finish ? acceptedElapsedSeconds(reads[finish.key]) : acceptedElapsedSeconds(reads.run_finish ?? reads.run_2_finish);
  const swimDistance = contest.legs.find((leg) => leg.type === "swim")?.distanceKm ?? 0;
  const bikeDistance = contest.legs.find((leg) => leg.type === "bike")?.distanceKm ?? 0;
  const runDistance = contest.legs.filter((leg) => ["run", "run_1", "run_2"].includes(leg.type)).reduce((sum, leg) => sum + leg.distanceKm, 0);
  const totalDistance = Math.max(Number(contest.configuredRaceDistanceKm || 0), Number(contest.totalDistanceKm || 0), contest.legs.reduce((sum, leg) => sum + Number(leg.distanceKm || 0), 0), ...contest.splits.map((split) => Number(split.cumulativeDistanceKm || 0)));
  return { swimSeconds, t1Seconds, bikeSeconds, t2Seconds, runSeconds, overallSeconds, averageSwimPaceSecondsPer100m: divide(swimSeconds, swimDistance * 10), averageBikeSpeedKmh: bikeSeconds && bikeDistance > 0 ? bikeDistance / (bikeSeconds / 3600) : null, averageRunPaceSecondsPerKm: divide(runSeconds, runDistance), averageRacePaceSecondsPerKm: divide(overallSeconds, totalDistance) };
}
