import type { StartConfiguration, StartReadStatus, StartTimingState, TimingMode, TimingPassage, TimingRead } from "./types.js";

export const DEFAULT_START_CONFIGURATION: StartConfiguration = {
  mode: "GUN", gunStartTime: null, ignoreReadsBeforeOfficialStart: true, dedupWindowSeconds: 5,
  validWindowMinutes: 30, dnsGraceMinutes: 60, strictFinalCutoff: false, startWindowOpenTime: null,
  startWindowCloseTime: null, passageGapSeconds: 3, timingReorderBufferMs: 2000,
  lockFirstAcceptedRead: true, storeAllRawReads: true, minimumFinishGapSeconds: 300,
  requireMandatorySplitsBeforeFinish: true,
};

function iso(value: unknown): string | null { const normalized = String(value ?? "").trim(); if (!normalized) return null; const parsed = Date.parse(normalized); return Number.isFinite(parsed) ? new Date(parsed).toISOString() : null; }
function bounded(value: unknown, fallback: number, minimum: number, maximum: number): number { const parsed = Number(value); return Number.isFinite(parsed) ? Math.min(maximum, Math.max(minimum, parsed)) : fallback; }

export function normalizeStartConfiguration(value: unknown): StartConfiguration {
  const row = value && typeof value === "object" ? value as Record<string, unknown> : {};
  const rawMode = String(row.mode ?? row.startMode ?? row.startTimingMode ?? "").trim().toUpperCase();
  const mode: TimingMode = rawMode === "CHIP" || rawMode === "WAVE" ? rawMode : "GUN";
  return {
    mode,
    gunStartTime: iso(row.gunStartTime ?? row.gun_start_time ?? row.officialStartTime ?? row.startWindowOpenTime),
    officialStartSource: row.officialStartSource === "FEIBOT_CONTEST" || row.officialStartSource === "TICKET_CONFIGURATION" || row.officialStartSource === "EVENT_CONFIGURATION" ? row.officialStartSource : null,
    ignoreReadsBeforeOfficialStart: true,
    dedupWindowSeconds: bounded(row.dedupWindowSeconds ?? row.startDedupWindowSeconds, 5, 0, 120),
    validWindowMinutes: bounded(row.validWindowMinutes ?? row.startReadAfterMinutes, 30, 1, 240),
    dnsGraceMinutes: bounded(row.dnsGraceMinutes ?? row.dns_grace_minutes, 60, 1, 1_440),
    strictFinalCutoff: row.strictFinalCutoff === true,
    startWindowOpenTime: iso(row.startWindowOpenTime ?? row.start_window_open_time ?? row.gunStartTime ?? row.officialStartTime),
    startWindowCloseTime: iso(row.startWindowCloseTime ?? row.start_window_close_time),
    passageGapSeconds: bounded(row.passageGapSeconds ?? row.startPassageGapSeconds, 3, 0.1, 30),
    timingReorderBufferMs: bounded(row.timingReorderBufferMs, 2000, 0, 10000),
    lockFirstAcceptedRead: true, storeAllRawReads: true,
    minimumFinishGapSeconds: bounded(row.minimumFinishGapSeconds, 300, 0, 86_400),
    requireMandatorySplitsBeforeFinish: row.requireMandatorySplitsBeforeFinish !== false,
  };
}

export function emptyStartTimingState(): StartTimingState {
  return { officialStartTime: null, chipStartDetectionTime: null, startTimeSource: null, startTimeLocked: false, acceptedReadId: null, startPassageId: null, startReadCount: 0, startStatus: "NOT_STARTED", updatedAt: null, startInferenceSource: null };
}

export interface ResolvedStart { timingMode: TimingMode; resolvedAthleteStartTime: string | null; startSource: NonNullable<StartTimingState["startInferenceSource"]>; }
export function resolveOfficialAthleteStart(input: { configuration: StartConfiguration; waveStartTime?: string | null; acceptedChipStartTime?: string | null; manualOverrideTime?: string | null; }): ResolvedStart {
  const manual = iso(input.manualOverrideTime);
  if (manual) return { timingMode: input.configuration.mode, resolvedAthleteStartTime: manual, startSource: "manual_override" };
  if (input.configuration.mode === "GUN") return { timingMode: "GUN", resolvedAthleteStartTime: iso(input.configuration.gunStartTime ?? input.configuration.startWindowOpenTime), startSource: "official_gun_start" };
  if (input.configuration.mode === "WAVE") return { timingMode: "WAVE", resolvedAthleteStartTime: iso(input.waveStartTime), startSource: "official_wave_start" };
  const accepted = iso(input.acceptedChipStartTime);
  return { timingMode: "CHIP", resolvedAthleteStartTime: accepted, startSource: accepted ? "accepted_chip_start" : "awaiting_chip_start" };
}

export interface StartReadDecision { status: StartReadStatus; reason: string; permittedStartTime: string | null; state: StartTimingState; canonicalRead: TimingRead | null; }
export function processStartTimingRead(input: { configuration: StartConfiguration; waveStartTime?: string | null; currentState?: StartTimingState | null; read: TimingRead; }): StartReadDecision {
  const { configuration, read } = input; const current = input.currentState ?? emptyStartTimingState();
  const readAt = iso(read.timestamp ?? read.occurredAt); const gunStart = iso(configuration.startWindowOpenTime ?? configuration.gunStartTime); const waveStart = iso(input.waveStartTime);
  const permittedStartTime = configuration.mode === "WAVE" ? waveStart : configuration.mode === "CHIP" ? waveStart ?? gunStart : gunStart;
  const closeTime = iso(configuration.startWindowCloseTime) ?? (permittedStartTime ? new Date(Date.parse(permittedStartTime) + configuration.validWindowMinutes * 60_000).toISOString() : null);
  const resolved = resolveOfficialAthleteStart({ configuration, waveStartTime: waveStart, acceptedChipStartTime: current.chipStartDetectionTime });
  const fixedOfficialStart = configuration.mode === "CHIP" ? null : resolved.resolvedAthleteStartTime;
  const base: StartTimingState = { ...current, officialStartTime: current.officialStartTime ?? fixedOfficialStart, startTimeSource: current.startTimeSource ?? (fixedOfficialStart ? configuration.mode : null), startInferenceSource: current.startInferenceSource ?? resolved.startSource };
  if (!readAt) return { status: "INVALID", reason: "reader_timestamp_invalid", permittedStartTime, state: base, canonicalRead: null };
  if (!permittedStartTime) return { status: "INVALID", reason: "permitted_start_missing", permittedStartTime: null, state: base, canonicalRead: null };
  const readMillis = Date.parse(readAt); const permittedMillis = Date.parse(permittedStartTime);
  if (readMillis < permittedMillis) return { status: "PRE_START", reason: "before_permitted_start", permittedStartTime, state: base, canonicalRead: null };
  const acceptedAt = iso(current.chipStartDetectionTime); const alreadyFinal = acceptedAt !== null || (current.startTimeLocked && (configuration.mode === "CHIP" || Boolean(current.acceptedReadId)));
  if (alreadyFinal) {
    const withinDedup = acceptedAt !== null && readMillis - Date.parse(acceptedAt) <= configuration.dedupWindowSeconds * 1000;
    return { status: withinDedup ? "DUPLICATE" : "IGNORED", reason: withinDedup ? "within_start_dedup_window" : "start_time_already_locked", permittedStartTime, state: base, canonicalRead: null };
  }
  if (closeTime && readMillis > Date.parse(closeTime)) return { status: "IGNORED", reason: "outside_valid_start_window", permittedStartTime, state: { ...base, startStatus: "NO_START_DETECTION", updatedAt: read.receivedAt || readAt }, canonicalRead: null };
  const officialStartTime = configuration.mode === "CHIP" ? readAt : fixedOfficialStart;
  if (!officialStartTime) return { status: "INVALID", reason: "official_start_missing", permittedStartTime, state: base, canonicalRead: null };
  const state: StartTimingState = { officialStartTime, chipStartDetectionTime: readAt, startTimeSource: configuration.mode, startTimeLocked: configuration.lockFirstAcceptedRead, acceptedReadId: read.readId, startPassageId: current.startPassageId ?? null, startReadCount: Math.max(1, current.startReadCount ?? 0), startStatus: "ON_COURSE", updatedAt: read.receivedAt || readAt, startInferenceSource: configuration.mode === "CHIP" ? "accepted_chip_start" : configuration.mode === "WAVE" ? "official_wave_start" : "official_gun_start" };
  const overallElapsedSeconds = Math.max(0, (readMillis - Date.parse(officialStartTime)) / 1000);
  return { status: "VALID", reason: configuration.mode === "CHIP" ? "first_valid_chip_start" : "valid_start_detection", permittedStartTime, state, canonicalRead: { ...read, timestamp: readAt, occurredAt: readAt, elapsedSeconds: overallElapsedSeconds, overallElapsedSeconds, status: "valid" } };
}

export interface StartPassageDecision extends StartReadDecision { passage: TimingPassage; rawStatus: StartReadStatus; usedForTiming: boolean; }
function samePassage(passage: TimingPassage, timestampValue: string, gapSeconds: number, reorderBufferMs: number): boolean {
  const timestamp = Date.parse(timestampValue); const first = Date.parse(passage.passageFirstTimestamp); const last = Date.parse(passage.passageLastTimestamp); const gap = Math.max(0, gapSeconds) * 1000; const earlierAllowance = Math.max(gap, Math.max(0, reorderBufferMs));
  return timestamp >= first - earlierAllowance && timestamp <= last + gap;
}
export function processStartPassageRead(input: { configuration: StartConfiguration; waveStartTime?: string | null; currentState?: StartTimingState | null; activePassage?: TimingPassage | null; read: TimingRead; bib?: string | null; chipCode?: string | null; }): StartPassageDecision {
  const readAt = iso(input.read.timestamp ?? input.read.occurredAt); const receivedAt = iso(input.read.receivedAt) ?? readAt ?? "1970-01-01T00:00:00.000Z"; const decision = processStartTimingRead(input);
  const initialStatus: TimingPassage["passageStatus"] = decision.status === "VALID" ? "VALID_START" : decision.status === "PRE_START" ? "PRE_START" : decision.status === "MANUAL" ? "MANUAL" : "INVALID";
  const next: TimingPassage = { id: `start-passage:${input.read.readId}`, eventId: input.read.eventId, contestUuid: input.read.contestUuid, participantUuid: input.read.participantUuid || input.read.providerParticipantUuid, bib: input.bib ?? input.read.bib ?? null, chipCode: input.chipCode ?? input.read.chipCode ?? null, timingPointUuid: input.read.providerTimingPointId, timingPointType: "START", readerUuid: input.read.readerUuid ?? null, passageFirstTimestamp: readAt ?? input.read.occurredAt ?? receivedAt, passageLastTimestamp: readAt ?? input.read.occurredAt ?? receivedAt, readCount: 1, passageStatus: initialStatus, usedForTiming: decision.status === "VALID", createdAt: receivedAt, updatedAt: receivedAt };
  const canAttach = Boolean(readAt && input.activePassage && samePassage(input.activePassage, readAt, input.configuration.passageGapSeconds, input.configuration.timingReorderBufferMs) && !(input.activePassage.passageStatus === "PRE_START" && decision.status !== "PRE_START") && !(input.activePassage.passageStatus !== "PRE_START" && decision.status === "PRE_START"));
  if (!canAttach) {
    if (decision.status === "IGNORED" && input.currentState?.startTimeLocked) { next.passageStatus = "SECOND_PASSAGE"; next.usedForTiming = false; return { ...decision, status: "SECOND_PASSAGE", rawStatus: "SECOND_PASSAGE", reason: "later_start_passage_after_locked_start", passage: next, usedForTiming: false, canonicalRead: null }; }
    const state = decision.status === "VALID" ? { ...decision.state, startPassageId: next.id, startReadCount: 1 } : decision.state;
    return { ...decision, state, passage: next, rawStatus: decision.status, usedForTiming: decision.status === "VALID" };
  }
  const active = input.activePassage!; const actualReadAt = readAt!;
  const firstTimestamp = new Date(Math.min(Date.parse(active.passageFirstTimestamp), Date.parse(actualReadAt))).toISOString(); const lastTimestamp = new Date(Math.max(Date.parse(active.passageLastTimestamp), Date.parse(actualReadAt))).toISOString();
  const passage: TimingPassage = { ...active, passageFirstTimestamp: firstTimestamp, passageLastTimestamp: lastTimestamp, readCount: active.readCount + 1, updatedAt: receivedAt };
  if (active.passageStatus === "PRE_START") return { ...decision, status: "PRE_START", rawStatus: "PRE_START", reason: "grouped_pre_start_passage", passage, usedForTiming: false, canonicalRead: null };
  if (active.passageStatus === "VALID_START" && active.usedForTiming) {
    const earlier = firstTimestamp < active.passageFirstTimestamp;
    const state: StartTimingState = { ...(input.currentState ?? decision.state), officialStartTime: input.configuration.mode === "CHIP" && earlier ? firstTimestamp : (input.currentState?.officialStartTime ?? decision.state.officialStartTime), chipStartDetectionTime: earlier ? firstTimestamp : (input.currentState?.chipStartDetectionTime ?? active.passageFirstTimestamp), startPassageId: active.id, startReadCount: passage.readCount };
    const canonicalRead = earlier && input.configuration.mode === "CHIP" ? { ...input.read, timestamp: firstTimestamp, occurredAt: firstTimestamp, timeOfDay: firstTimestamp.slice(11, 19), elapsedSeconds: 0, status: "valid" } : null;
    return { ...decision, status: "DUPLICATE", rawStatus: "DUPLICATE", reason: earlier ? "out_of_order_read_attached_to_start_passage" : "read_attached_to_start_passage", state, passage, usedForTiming: false, canonicalRead };
  }
  return { ...decision, status: "DUPLICATE", rawStatus: "DUPLICATE", reason: "read_grouped_into_existing_passage", passage, usedForTiming: false, canonicalRead: null };
}
